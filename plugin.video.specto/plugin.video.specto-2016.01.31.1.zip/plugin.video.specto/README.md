======================
Specto
======================

About
-----
Mrknow fork of Genesis


======================
Genesis
======================

About
-----
The origins of streaming


Attributions
---------------------
- 4orbs theme by Marquerite | http://tvaddons.ag
- Clean theme by jokster | http://tvaddons.ag
- Embossed theme by jokster | http://tvaddons.ag
- GOne theme by jokster | http://tvaddons.ag
- Metro theme by rayw1986 | http://tvaddons.ag


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html